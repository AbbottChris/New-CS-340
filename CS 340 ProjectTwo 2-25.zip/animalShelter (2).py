from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        if username and password:
            print("username and password are: ", username, password)
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:30052/AAC' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']
        print("Connection was successful")

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is None:
            raise Exception("Nothing to save, because data parameter is empty")
        else: 
            insertTrue = self.database.animals.insert_one(data)  # data should be dictionary           
            if insertTrue is None:
                return False
            else:
                return True
            
         
            

# Create method to implement the R set in CRUD. 
    def read(self, data):
        if data is None:          # checking to see if the item is in record
            print("ERROR. No data collected")
        else:
            results = self.database.animals.find(data, {"_id": False})
        if results is None:
            print("ERROR - No data collected")
             
        else:
            return results 
            
# Create method to implement the U in CRUD
    def update(self, data, update):
        if data is not None:   # checking to see if the item is in the database
            results = self.database.animals.update_many(data, { "$set": update})
        else:                     # updates the item in the database
            return "{}"
        return results
    
    
# Create method to implement the D in CRUD
    def delete(self, data):
        if data is not None:    # checking to see if the item is in the database
            results = self.database.animals.delete_many(data)
        else:                     # deletes the item in the database
            return "{}"
        return results
              
            
                
                        
            